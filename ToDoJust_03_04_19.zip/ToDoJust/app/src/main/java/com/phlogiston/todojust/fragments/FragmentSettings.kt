package com.phlogiston.todojust.fragments

import android.os.Bundle
import android.support.v4.app.Fragment
import android.view.*
import com.phlogiston.todojust.R.*

class FragmentSettings : Fragment() {
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(layout.fragment_settings, container, false)
    }
}