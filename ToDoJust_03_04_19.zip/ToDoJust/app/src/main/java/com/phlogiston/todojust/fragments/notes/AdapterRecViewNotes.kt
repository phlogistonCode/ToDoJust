package com.phlogiston.todojust.fragments.notes

import android.support.v7.widget.RecyclerView
import android.view.*
import android.widget.TextView
import com.phlogiston.todojust.R

class AdapterRecViewNotes(private val values: List<String>): RecyclerView.Adapter<AdapterRecViewNotes.ViewHolder>() {

    override fun getItemCount() = values.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.recview_item_notes, parent, false)
        return ViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.textView?.text = values[position]
    }

    class ViewHolder(itemView: View): RecyclerView.ViewHolder(itemView) {
        var textView: TextView? = null
        init {
            textView = itemView.findViewById(R.id.text_item_notes)
        }
    }
}