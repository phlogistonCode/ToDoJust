package com.phlogiston.todojust

import android.os.Bundle
import android.support.design.widget.BottomNavigationView
import android.support.v4.app.Fragment
import android.support.v7.app.AppCompatActivity
import com.phlogiston.todojust.R.id.*
import com.phlogiston.todojust.fragments.*
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    private val mOnNavigationItemSelectedListener = BottomNavigationView.OnNavigationItemSelectedListener { item ->
        when (item.itemId) {
            navigation_notes -> {
                addFragment(FragmentNotes())
                return@OnNavigationItemSelectedListener true
            }
            navigation_planning -> {
                addFragment(FragmentPlanning())
                return@OnNavigationItemSelectedListener true
            }
            navigation_settings -> {
                addFragment(FragmentSettings())
                return@OnNavigationItemSelectedListener true
            }
        }
        false
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener)
        supportFragmentManager
            .beginTransaction()
            .replace(fragment_container.id, FragmentPlanning(), FragmentPlanning().javaClass.simpleName)
            .commit()
    }

    private fun addFragment(fragment: Fragment) {
        supportFragmentManager
            .beginTransaction()
            .setCustomAnimations(R.anim.design_sheet_slide_in, 0)
            .replace(fragment_container.id, fragment, fragment.javaClass.simpleName)
            .commit()
    }

}
