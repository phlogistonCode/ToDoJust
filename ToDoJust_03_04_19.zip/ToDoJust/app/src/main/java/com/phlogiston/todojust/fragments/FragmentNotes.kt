package com.phlogiston.todojust.fragments

import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.*
import com.phlogiston.todojust.R.*
import com.phlogiston.todojust.fragments.notes.AdapterRecViewNotes
import kotlinx.android.synthetic.main.fragment_notes.*

class FragmentNotes : Fragment() {

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {

        return inflater.inflate(layout.fragment_notes, container, false)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        recViewNotes.layoutManager = LinearLayoutManager(activity)
        recViewNotes.adapter = AdapterRecViewNotes(generateRndValues())
    }

    private fun generateRndValues(): List<String> {
        val values = mutableListOf<String>()
        for (i in 0..20) values.add("$i element")

        return values
    }

}